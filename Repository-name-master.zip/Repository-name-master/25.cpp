#include<iostream>
#include<cmath>
using namespace std;
int main(){
int x,a,y;
cin>>x>>a>>y;
cout<<(x*7)+(a*30)+(y*365);
}
