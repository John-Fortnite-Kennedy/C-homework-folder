#include<iostream>
#include<cmath>
using namespace std;
int main(){
int x,y,z,a,b;
cin>>x>>y>>z;
a=x+y;
b=y+z;
if (a>b){cout<<x<<" "<<y;} else {cout<<y<<" "<<z;}
}
