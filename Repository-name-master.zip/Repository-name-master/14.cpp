#include<iostream>
#include<cmath>
using namespace std;
int main(){
double a,b;
cin>>a>>b;
cout<<a+b<<" "<<a*b;
}
