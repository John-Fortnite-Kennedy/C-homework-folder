#include<iostream>
#include<cmath>
using namespace std;
int main(){
double a,b,c;
cin>>a>>b>>c;
cout<<(a*2)+(b-3)+pow(c,2);
}
