#include<iostream>
#include<cmath>
using namespace std;
int main(){
int x,y,z,a,u=0;
cin>>x>>y>>z>>a;
if (x==y){cout<<"yes";}
if (x==z){cout<<"yes";}
if (x==a){cout<<"yes";}
if (y==z){cout<<"yes";}
if (y==a){cout<<"yes";}
if (z==a){cout<<"yes";}
}
