#include<iostream>
#include<cmath>
using namespace std;
int main(){
double a=(-2.34);
cout<<( ((sqrt(pow(a-5,2)) )-sin(a))/ 3)+sqrt(pow(a,2)+2014)*cos(2*a)-3;
}
