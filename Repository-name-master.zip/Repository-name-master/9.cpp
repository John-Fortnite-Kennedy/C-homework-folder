#include<iostream>
#include<cmath>
using namespace std;
int main(){
int a=(-2);
cout<<sqrt(pow(a,2))+pow(a,5);
}
