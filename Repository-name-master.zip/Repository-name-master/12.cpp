#include<iostream>
#include<cmath>
using namespace std;
int main(){
double a=3.6;
cout<<exp(a-2)+sqrt(pow(sin(a),2))-pow(a,4)*cos(1/a);
}
