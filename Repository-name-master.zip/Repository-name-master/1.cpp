#include<iostream>
using namespace std;
int main(){
cout<<"\"Silence is golden\".";
}
