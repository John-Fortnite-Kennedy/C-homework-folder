#include<iostream>
#include<cmath>
using namespace std;
int main(){
int a=647,b=170,c=30;
cout<<(a*b)/(c*c);
}
