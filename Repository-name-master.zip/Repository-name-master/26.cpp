#include<iostream>
#include<cmath>
using namespace std;
int main(){
int x,a,c;
cin>>x>>a;
c=x;
x=a;
a=c;
cout<<x<<" "<<a;
}
