#include<iostream>
using namespace std;
int main(){
    for(int i=0;i<4;i++){
          switch(i){
        case 0:
        cout<<"*     *     *"<<endl;
        break;
        case 1:
        cout<<" *   * *   *"<<endl;
        break;
        case 2:
        cout<<"  * *   * *"<<endl;
        break;
        case 3:
        cout<<"   *     *"<<endl;
        break;
        }
}
}
