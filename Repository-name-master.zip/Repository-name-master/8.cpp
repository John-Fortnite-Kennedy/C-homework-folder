#include<iostream>
#include<cmath>
using namespace std;
int main(){
int a=2;
int b=3;
cout<<(a+4*b)*(a-3*b)+pow(a,2);
}
