#include<iostream>
using namespace std;
int main(){
    int n=5,count=1;
    for(int i=0;i<n;i++){
          for(int j=0;j<count;j++){
            cout<<0;
          }
          count++;
          cout<<endl;
}
}
