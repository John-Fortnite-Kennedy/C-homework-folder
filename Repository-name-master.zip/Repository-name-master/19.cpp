#include<iostream>
#include<cmath>
using namespace std;
int main(){
double a,b ;
cin>>a>>b;
cout<<0.3*a+0.4*b<<" "<<3*(2*b+1.8*a);
}
