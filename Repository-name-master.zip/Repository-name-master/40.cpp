#include<iostream>
#include<cmath>
using namespace std;
int main(){
int x;
cin>>x;
if (x>-10&&x<10){x+=5;cout<<x;} else {x-=10;cout<<x;}
}
