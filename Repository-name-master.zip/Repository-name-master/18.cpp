#include<iostream>
#include<cmath>
using namespace std;
int main(){
double a ;
cin>>a;
cout<<4*a<<" "<<a*a;
}
