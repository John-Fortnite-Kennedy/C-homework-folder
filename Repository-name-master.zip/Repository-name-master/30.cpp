#include<iostream>
#include<cmath>
using namespace std;
int main(){
int a,b,c;
b=a*a;
c=a*a*a;
cout<<a*a*b<<" "<<b*b*b<<" "<<c*c*c*c*c;
}
