#include<iostream>
#include<cmath>
using namespace std;
int main(){
double a,b;
cin>>a>>b;
cout<<(b/1000)/(a/60);
}
