#include<iostream>
#include<cmath>
using namespace std;
int main(){
int x,y;
cin>>x>>y;
if (sqrt(pow(x-y,2))>=100){cout<<"yes";} else {cout<<"No";}
}
