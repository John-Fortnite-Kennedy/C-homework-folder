#include<iostream>
#include<cmath>
using namespace std;
int main(){
double a;
cin>>a;
cout<<(a*9/5)+32;
}
