#include<iostream>
#include<cmath>
using namespace std;
int main(){
int x,a,y,k;
cin>>x>>a>>y>>k;
cout<<(y*a)/x<<" "<<k/(a/x);
}
