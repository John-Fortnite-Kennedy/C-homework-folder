#include<iostream>
#include<cmath>
using namespace std;
int main(){
double x,y;
cin>>x>>y;
cout<<sqrt(x-sqrt(y));
}
