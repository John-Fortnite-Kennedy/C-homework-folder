#include<iostream>
#include<cmath>
using namespace std;
int main(){
int x;
cin>>x;
if (x<7){cout<<"Yes";}
else if (x>10){cout<<"No";}
else if (x==9){cout<<"Error";}
cout<<x;
}
