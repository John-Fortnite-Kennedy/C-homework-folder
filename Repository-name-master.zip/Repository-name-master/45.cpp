#include<iostream>
#include<cmath>
using namespace std;
int main(){
int x,y,z;
cin>>x>>y>>z;
if((x+y+z)>10){
        if ((x%2)==0){
                 if ((y%2)==0){cout<<"yes";} else {cout<<"no";}
} else {cout<<"no";}
} else {cout<<"no";}}
