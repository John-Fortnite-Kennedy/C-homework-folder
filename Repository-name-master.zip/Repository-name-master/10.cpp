#include<iostream>
#include<cmath>
using namespace std;
int main(){
float a=1.7;
cout<<pow(a+1,2)+3*(a+1)<<endl;
int b=3;
cout<<pow(b+1,2)+3*(b+1);
}
