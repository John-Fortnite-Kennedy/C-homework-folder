#include<iostream>
using namespace std;
int main(){
cout<<"Tuesday\n";
cout<<"November\n";
cout<<"Alibek\n";
}
