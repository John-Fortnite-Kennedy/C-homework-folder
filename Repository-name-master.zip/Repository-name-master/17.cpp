#include<iostream>
#include<cmath>
using namespace std;
int main(){
double a,b,c;
cin>>a>>b>>c;
cout<<(a+b+c)/3<<" "<<2*(a+c)-3*b;
}
