#include<iostream>
#include<cmath>
using namespace std;
int main(){
double a=1.0/2.0;
double b=1.0/4.0;
cout<<a+b;
}
