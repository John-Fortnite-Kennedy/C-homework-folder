#include<iostream>
using namespace std;
int main(){
cout<<1+2-4;
}
