#include<iostream>
#include<cmath>
using namespace std;
int main(){
double a;
cin>>a;
cout<<pow(a,2)<<" "<<pow(a,3);
}
